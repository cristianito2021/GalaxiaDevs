import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import {BasicTableComponent} from '../components/basic-table/basic-table.component'
import {AdvancedTableComponent} from '../components/advanced-table/advanced-table.component'
import { FormsModule } from '@angular/forms';


export interface columnDef{
  title: string;
  textColor: string;
  bgColor: string;
  name: string;
}

export interface response{
  data: any[];
  perPage: number;
  page: number;
  status: number;
}

export interface ITableFactory {
  createTable(ref: any, params: { response: response, columnDefs: columnDef[], mustSearch: boolean, mustPaginator: boolean}): void;
}

@NgModule({
  declarations: [BasicTableComponent],
  imports: [CommonModule, FormsModule],
  exports: [BasicTableComponent]
})

export class BasicTableFactory implements ITableFactory {
  createTable(ref: any, params: { response: response, columnDefs: columnDef[], mustSearch: boolean, mustPaginator: boolean }): void {

    ref.instance.data = params.response.data;
    ref.instance.perPage = params.response.perPage;
    ref.instance.page = params.response.page;
    ref.instance.status = params.response.status;
    ref.instance.columnDefs = params.columnDefs;
    ref.instance.mustSearch = params.mustSearch;
    ref.instance.mustPaginator = params.mustPaginator;
    ref.changeDetectorRef.detectChanges();
  }
}

export class AdvancedTableFactory implements ITableFactory {
  createTable(): any {
    // Aquí iría la lógica para crear una tabla avanzada.
    return new AdvancedTableComponent();
  }
}
