import { CommonModule } from '@angular/common';
import { Component, ComponentRef, ViewChild, AfterViewInit, OnInit } from '@angular/core';
import { BasicTableFactory, response } from './table-factory';
import { DynamicDirectiveDirective } from '../directives/dynamic-directive.directive'
import { BasicTableComponent } from '../components/basic-table/basic-table.component'

@Component({
  selector: 'app-table-container',
  standalone: true,
  imports: [CommonModule, DynamicDirectiveDirective],
  providers: [BasicTableFactory],
  templateUrl: './table-container.component.html',
  styleUrl: './table-container.component.css'
})

export class TableContainerComponent implements AfterViewInit {
  @ViewChild(DynamicDirectiveDirective, {static: false}) dynamicComponent!: DynamicDirectiveDirective;
  dynamicComponentRef!: ComponentRef<BasicTableComponent>

  tableComponent: any;

  constructor(private basicTableFactory: BasicTableFactory) {}

  ngAfterViewInit() {
    this.loadDynamicComponent();
    this.basicTableFactory.createTable(
      this.dynamicComponentRef,
      {
        columnDefs: [
          {
            title: 'Nombre',
            textColor: 'white',
            bgColor: 'black',
            name: 'full_name'
          },
          {
            title: 'Apellido',
            textColor: 'white',
            bgColor: 'black',
            name: 'last_name'
          }
        ],
        response: this.getUsers(),
        mustSearch: true,
        mustPaginator: true
      }
    )
  }

  loadDynamicComponent() {
    const viewContainerRef = this.dynamicComponent.viewContainerRef;
    this.dynamicComponentRef = viewContainerRef.createComponent(BasicTableComponent);
  }

  getUsers(){
    let respose: response = {
      data:[
        {
          full_name: 'Cristian',
          last_name: 'Trejo',
        },
        {
          full_name: 'Carlos',
          last_name: 'Silva',
        },
        {
          full_name: 'Yoel',
          last_name: 'Ayan',
        },
        {
          full_name: 'Juan',
          last_name: 'Perez',
        },
        {
          full_name: 'Maria',
          last_name: 'Gonzalez',
        },
        {
          full_name: 'Pedro',
          last_name: 'Martinez',
        },
        {
          full_name: 'Ana',
          last_name: 'Rodriguez',
        },
        {
          full_name: 'Luis',
          last_name: 'Garcia',
        },
        {
          full_name: 'Sofia',
          last_name: 'Fernandez',
        },
        {
          full_name: 'Miguel',
          last_name: 'Lopez',
        },
        {
          full_name: 'Patricia',
          last_name: 'Morales',
        },
        {
          full_name: 'Ricardo',
          last_name: 'Guerrero',
        },
        {
          full_name: 'Isabel',
          last_name: 'Peña',
        },
        {
          full_name: 'Jorge',
          last_name: 'Ramos',
        },
        {
          full_name: 'Sara',
          last_name: 'Torres',
        },
        {
          full_name: 'Diego',
          last_name: 'Sanchez',
        },
        {
          full_name: 'Laura',
          last_name: 'Castillo',
        },
        {
          full_name: 'Fernando',
          last_name: 'Aguilar',
        }
    ],
      perPage: 5,
      page: 1,
      status: 200
    };

    return respose;
  }
}
