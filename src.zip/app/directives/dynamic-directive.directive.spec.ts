import { DynamicDirectiveDirective } from './dynamic-directive.directive';

describe('DynamicDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new DynamicDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
