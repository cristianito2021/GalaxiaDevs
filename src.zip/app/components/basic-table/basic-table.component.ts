import { Component, Input } from '@angular/core';
import { BasicTableInterface } from './basic-table.interface';


@Component({
  selector: 'app-basic-table',
  templateUrl: './basic-table.component.html',
  styleUrls: ['./basic-table.component.css']
})


export class BasicTableComponent implements BasicTableInterface {
  @Input() columnDefs!: any[];
  @Input() data!: any[];
  @Input() perPage!: number;
  @Input() page!: number;
  @Input() status!: number;
  @Input() mustSearch!: number;
  @Input() mustPaginator!: number;

  filterText = '';

  sortOrder = 1;
  sortedColumn: string = '';

  sort(columnName: string) {
    if (this.sortedColumn == columnName) {
      this.sortOrder = this.sortOrder * -1;
    } else {
      this.sortOrder = 1;
    }
    this.sortedColumn = columnName;

    this.data.sort((a, b) => {
      if (a[columnName] < b[columnName]) {
        return -1 * this.sortOrder;
      } else if (a[columnName] > b[columnName]) {
        return 1 * this.sortOrder;
      } else {
        return 0;
      }
    });
  }

  nextPage() {
    if (this.mustPaginator && this.page < this.totalPages) {
      this.page++;
    }
  }

  previousPage() {
    if (this.mustPaginator && this.page > 1) {
      this.page--;
    }
  }

  highlight(text: string) {
    if (!this.filterText) {
      return text;
    }

    const regex = new RegExp(this.filterText, 'gi');

    return text.replace(regex, match => `<mark>${match}</mark>`);
  }

  get dataCount() {
    return this.data.length;
  }

  get totalPages() {
    return Math.ceil(this.data.length / this.perPage);
  }

  get filteredData() {
    let data = this.data;

    if (this.filterText) {
      data = data.filter(row =>
        this.columnDefs.some(column =>
          row[column.name].toString().toLowerCase().includes(this.filterText.toLowerCase())
        )
      );
    }

    if (this.mustPaginator) {
      data = data.slice((this.page - 1) * this.perPage, this.page * this.perPage);
    }

    return data;
  }
}
