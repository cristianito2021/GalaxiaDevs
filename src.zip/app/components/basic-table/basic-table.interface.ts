export interface BasicTableInterface {
  columnDefs: any[];
  data: any[];
  perPage: number;
  page: number;
  status: number;
  mustSearch: number;
  mustPaginator: number;
  sort(columnName: string): void;
  nextPage(): void;
  previousPage(): void;
  highlight(text: string): string;
}
