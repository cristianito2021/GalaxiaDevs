import { Component } from '@angular/core';

@Component({
  selector: 'app-advanced-table',
  templateUrl: './advanced-table.component.html',
  styleUrls: ['./advanced-table.component.css']
})
export class AdvancedTableComponent {
  // Implementación del componente de una tabla avanzada.
}
