import { Routes } from '@angular/router';
import { TableContainerComponent } from './table-container/table-container.component';

export const routes: Routes = [
  { path: 'kk', component: TableContainerComponent }
];
